# Yolo_characters > 2024-07-23 10:30am
https://universe.roboflow.com/universidade-de-coimbra-8dtin/yolo_characters

Provided by a Roboflow user
License: CC BY 4.0

